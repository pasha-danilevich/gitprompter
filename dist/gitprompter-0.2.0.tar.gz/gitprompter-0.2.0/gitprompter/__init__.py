"""gitprompter"""
from gitprompter.config import GitPrompterConfig

config_instance = GitPrompterConfig()