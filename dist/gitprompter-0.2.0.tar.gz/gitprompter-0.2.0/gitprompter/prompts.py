from enum import StrEnum

from gitprompter import config_instance

class AnswerFormat(StrEnum):
    FORMAT = f'Please write your ANSWER in either "code" or "plaintext" format, using the "{config_instance.language}" language.'

class FeaturePrompt(StrEnum):
    """Prompts focused on new features"""
    COMMIT = (
        "Task:\n"
        "Write a comment for my commit using the following structure:\n"
        "{a brief commit title summarizing the essence}\n"
        "{caret symbol for indentation (enter)}\n"
        "{list of changes (each starting with a dash)}\n"
        f'{AnswerFormat.FORMAT}\n\n'
    )

    PULL_REQUEST = (
        "Task:\n"
        "Write a comment for my Pull Request following this structure:\n"
        "{a brief Pull Request title summarizing the main idea}\n"
        "{caret symbol for indentation (enter)}\n"
        "{list of changes (each starting with a dash)}\n"
        f'{AnswerFormat.FORMAT}\n\n'
        "Comments of all commits in the current branch:\n\n"
    )



class ConventionalCommitPrompt(StrEnum):
    """
    Conventional Commits — это простой стандарт (соглашение)
    для написания сообщений коммитов в системах контроля версий.
    Цель стандарта — сделать историю изменений проекта более понятной и удобной для чтения,
    а также упростить автоматизацию таких процессов,
    как версионирование, генерация CHANGELOG и CI/CD.
    """
    COMMIT = (
        "Задача:\n"
    )